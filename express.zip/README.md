# template-nodejs
Repository de module pour tester la génération de projet à partir du module 
https://www.npmjs.com/package/create-project
